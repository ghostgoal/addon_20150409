
  if (!zcExistsAlready) {
    delete window.ZeroClipboard;
  }

})(
  jQuery,
  (function() {
    /*jshint strict: false */
    return this || window;
  })()
);
